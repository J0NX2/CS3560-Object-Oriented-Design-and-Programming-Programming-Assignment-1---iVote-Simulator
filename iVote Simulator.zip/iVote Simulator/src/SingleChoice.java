public class SingleChoice extends Question{
	private String answer;
	
	public void setSingle() {
		int min = 0;
		int max = 3;
		
		int random = (int)(Math.random() * (max - min + 1) + min);
		String[] question = {"A", "B", "C", "D"};
		answer = question[random]; // chooses a random answer
	}
	
	public String getSingle() {
		return answer;
	}
}
