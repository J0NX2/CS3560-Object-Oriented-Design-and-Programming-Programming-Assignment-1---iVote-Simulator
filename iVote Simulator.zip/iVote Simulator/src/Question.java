import java.util.Random;
public class Question{
	boolean questionType;
	
	public void setType() {
		Random rd = new Random();
		questionType = rd.nextBoolean(); // single if true, multiple if false
	}
	
	public boolean getType() {
		return questionType;
	}
}
