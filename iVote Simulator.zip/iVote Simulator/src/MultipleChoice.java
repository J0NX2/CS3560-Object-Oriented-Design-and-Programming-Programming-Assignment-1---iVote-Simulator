import java.util.Random;
public class MultipleChoice{
	private String answer;
	
	public void setMultiple() {
		Random rd = new Random();
		boolean emptyAnswer = true;
		
		String[] posAnswer = {"A", "B", "C", "D"};
		do {
		for(int i=0; i<4; i++) {
			if(rd.nextBoolean()) {	// randomly decides wrong answers and replaces with '.'
				answer += posAnswer[i];
				emptyAnswer = false;
			}
		}
		}while(emptyAnswer); // ensures there is an answer
	}
	
	public String getMultiple() {
		return answer;
	}
}
