public class SimulationDriver {
	
	public static void main(String[] args) {
		Question[] question = new Question[10];
		String[] questionList = new String[10];
		VotingService vote = new VotingService();
		
		// creates 10 questions
		for(int i=0; i<10; i++) {
			Question q = new Question();
			q.setType(); // boolean value. single answer if true, multiple answers if false
			question[i] = q; // array of Question objects to keep track of question type
			
			if(q.getType()) {
				SingleChoice sc =  new SingleChoice();
				sc.setSingle();
				questionList[i] = sc.getSingle();
			}
			else {
				MultipleChoice mc = new MultipleChoice();
				mc.setMultiple();
				questionList[i] = mc.getMultiple();
			}
		}
		
		// creates a random number of students from 20 to 50
		int randomStudents = (int)(Math.random() * (50 - 20 + 1) + 20);
		Student[] studentList = new Student[randomStudents];
		
		// calls the voting service for every question
		for(int i=0; i<questionList.length; i++) {
			int questionNum = i+1;
			System.out.println("Question #" + questionNum);
			for(int j=0; j<randomStudents; j++) {
				Student student = new Student();
				student.setID();
				student.setAnswer(question[i].getType());
				studentList[j] = student;
			}
			vote.submission(questionList[i], studentList);
		}	
	}
}
