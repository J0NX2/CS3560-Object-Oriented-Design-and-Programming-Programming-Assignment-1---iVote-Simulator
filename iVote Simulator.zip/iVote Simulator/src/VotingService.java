
public class VotingService{
	public void submission(String question, Student[] student) {
		int right = 0;
		int wrong = 0;
		
		for(int i=0; i<student.length; i++) {
			if(question.equals(student[i].getAnswer())) {
				right++;
			}
			else {
				wrong++;
			}
		}
		System.out.println(student.length + " Students answered");
		System.out.println("Right : " + right + " Wrong : " + wrong + '\n');
	}
}
