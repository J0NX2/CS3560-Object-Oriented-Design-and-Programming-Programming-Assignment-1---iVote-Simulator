import java.util.UUID;
public class Student {
	private String studentID;
	private String answer;
	
	public void setID() {
		studentID = UUID.randomUUID().toString();
	}
	
	public String getID() {
		return studentID;
	}
	
	public void setAnswer(boolean qType) {
		if(qType) {
			SingleChoice s = new SingleChoice();
			s.setSingle();
			answer = s.getSingle();
		}
			
		else {
			MultipleChoice m = new MultipleChoice();
			m.setMultiple();
			answer = m.getMultiple();
		}
	}
	
	public String getAnswer() {
		return answer;
	}
}
	
